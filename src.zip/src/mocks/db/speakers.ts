import { Speaker, SpeakerInput } from '@/entities/speaker/model/types';

export const initialSpeakers = [
  {
    id: '4',
    userId: '4',
    name: 'Demo Speaker',
    email: 'demo.speaker@example.com',
    company: 'Acme Cloud',
    position: 'Frontend Engineer',
    bio: 'Demo Speaker работает в Acme Cloud и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/demo_speaker',
    pastTalks:
      'Demo Speaker: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Demo%20Speaker',
  },
  {
    id: 'speaker-002',
    userId: 'speaker-user-002',
    name: 'Kira Antonova',
    email: 'kira.antonova@example.com',
    company: 'Pixel Labs',
    position: 'Senior Frontend Engineer',
    bio: 'Kira Antonova работает в Pixel Labs и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/kira_antonova',
    pastTalks:
      'Kira Antonova: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Kira%20Antonova',
  },
  {
    id: 'speaker-003',
    userId: 'speaker-user-003',
    name: 'Oleg Romanov',
    email: 'oleg.romanov@example.com',
    company: 'DataMind',
    position: 'Backend Engineer',
    bio: 'Oleg Romanov работает в DataMind и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/oleg_romanov',
    pastTalks:
      'Oleg Romanov: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Oleg%20Romanov',
  },
  {
    id: 'speaker-004',
    userId: 'speaker-user-004',
    name: 'Nina Volkova',
    email: 'nina.volkova@example.com',
    company: 'ScaleOps',
    position: 'DevOps Engineer',
    bio: 'Nina Volkova работает в ScaleOps и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/nina_volkova',
    pastTalks:
      'Nina Volkova: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Nina%20Volkova',
  },
  {
    id: 'speaker-005',
    userId: 'speaker-user-005',
    name: 'Timur Galiev',
    email: 'timur.galiev@example.com',
    company: 'ProductHub',
    position: 'Product Manager',
    bio: 'Timur Galiev работает в ProductHub и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/timur_galiev',
    pastTalks:
      'Timur Galiev: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Timur%20Galiev',
  },
  {
    id: 'speaker-006',
    userId: 'speaker-user-006',
    name: 'Alina Safina',
    email: 'alina.safina@example.com',
    company: 'UX Works',
    position: 'Product Designer',
    bio: 'Alina Safina работает в UX Works и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/alina_safina',
    pastTalks:
      'Alina Safina: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Alina%20Safina',
  },
  {
    id: 'speaker-007',
    userId: 'speaker-user-007',
    name: 'Sergey Pavlov',
    email: 'sergey.pavlov@example.com',
    company: 'Northwind Tech',
    position: 'Tech Lead',
    bio: 'Sergey Pavlov работает в Northwind Tech и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/sergey_pavlov',
    pastTalks:
      'Sergey Pavlov: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Sergey%20Pavlov',
  },
  {
    id: 'speaker-008',
    userId: 'speaker-user-008',
    name: 'Daria Mikhailova',
    email: 'daria.mikhailova@example.com',
    company: 'AI Forge',
    position: 'ML Engineer',
    bio: 'Daria Mikhailova работает в AI Forge и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/daria_mikhailova',
    pastTalks:
      'Daria Mikhailova: production case studies, internal tooling, engineering practices',
    avatarUrl:
      'https://api.dicebear.com/8.x/initials/svg?seed=Daria%20Mikhailova',
  },
  {
    id: 'speaker-009',
    userId: 'speaker-user-009',
    name: 'Roman Egorov',
    email: 'roman.egorov@example.com',
    company: 'API Factory',
    position: 'Backend Architect',
    bio: 'Roman Egorov работает в API Factory и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/roman_egorov',
    pastTalks:
      'Roman Egorov: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Roman%20Egorov',
  },
  {
    id: 'speaker-010',
    userId: 'speaker-user-010',
    name: 'Ekaterina Zueva',
    email: 'ekaterina.zueva@example.com',
    company: 'Frontend Guild',
    position: 'Design System Lead',
    bio: 'Ekaterina Zueva работает в Frontend Guild и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/ekaterina_zueva',
    pastTalks:
      'Ekaterina Zueva: production case studies, internal tooling, engineering practices',
    avatarUrl:
      'https://api.dicebear.com/8.x/initials/svg?seed=Ekaterina%20Zueva',
  },
  {
    id: 'speaker-011',
    userId: 'speaker-user-011',
    name: 'Viktor Denisov',
    email: 'viktor.denisov@example.com',
    company: 'CloudNine',
    position: 'Platform Engineer',
    bio: 'Viktor Denisov работает в CloudNine и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/viktor_denisov',
    pastTalks:
      'Viktor Denisov: production case studies, internal tooling, engineering practices',
    avatarUrl:
      'https://api.dicebear.com/8.x/initials/svg?seed=Viktor%20Denisov',
  },
  {
    id: 'speaker-012',
    userId: 'speaker-user-012',
    name: 'Irina Markova',
    email: 'irina.markova@example.com',
    company: 'RetailSoft',
    position: 'Engineering Manager',
    bio: 'Irina Markova работает в RetailSoft и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/irina_markova',
    pastTalks:
      'Irina Markova: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Irina%20Markova',
  },
  {
    id: 'speaker-013',
    userId: 'speaker-user-013',
    name: 'Maxim Borisov',
    email: 'maxim.borisov@example.com',
    company: 'Open Source Lab',
    position: 'Fullstack Developer',
    bio: 'Maxim Borisov работает в Open Source Lab и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/maxim_borisov',
    pastTalks:
      'Maxim Borisov: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Maxim%20Borisov',
  },
  {
    id: 'speaker-014',
    userId: 'speaker-user-014',
    name: 'Polina Karpova',
    email: 'polina.karpova@example.com',
    company: 'TestCraft',
    position: 'QA Automation Engineer',
    bio: 'Polina Karpova работает в TestCraft и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/polina_karpova',
    pastTalks:
      'Polina Karpova: production case studies, internal tooling, engineering practices',
    avatarUrl:
      'https://api.dicebear.com/8.x/initials/svg?seed=Polina%20Karpova',
  },
  {
    id: 'speaker-015',
    userId: 'speaker-user-015',
    name: 'Andrey Belyaev',
    email: 'andrey.belyaev@example.com',
    company: 'Legacy Systems',
    position: 'Frontend Architect',
    bio: 'Andrey Belyaev работает в Legacy Systems и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/andrey_belyaev',
    pastTalks:
      'Andrey Belyaev: production case studies, internal tooling, engineering practices',
    avatarUrl:
      'https://api.dicebear.com/8.x/initials/svg?seed=Andrey%20Belyaev',
  },
  {
    id: 'speaker-016',
    userId: 'speaker-user-016',
    name: 'Yulia Sidorova',
    email: 'yulia.sidorova@example.com',
    company: 'Analytics Pro',
    position: 'Data Analyst',
    bio: 'Yulia Sidorova работает в Analytics Pro и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/yulia_sidorova',
    pastTalks:
      'Yulia Sidorova: production case studies, internal tooling, engineering practices',
    avatarUrl:
      'https://api.dicebear.com/8.x/initials/svg?seed=Yulia%20Sidorova',
  },
  {
    id: 'speaker-017',
    userId: 'speaker-user-017',
    name: 'Kirill Fomin',
    email: 'kirill.fomin@example.com',
    company: 'SecureStack',
    position: 'Security Engineer',
    bio: 'Kirill Fomin работает в SecureStack и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/kirill_fomin',
    pastTalks:
      'Kirill Fomin: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Kirill%20Fomin',
  },
  {
    id: 'speaker-018',
    userId: 'speaker-user-018',
    name: 'Natalia Osipova',
    email: 'natalia.osipova@example.com',
    company: 'Mobile First',
    position: 'React Native Developer',
    bio: 'Natalia Osipova работает в Mobile First и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/natalia_osipova',
    pastTalks:
      'Natalia Osipova: production case studies, internal tooling, engineering practices',
    avatarUrl:
      'https://api.dicebear.com/8.x/initials/svg?seed=Natalia%20Osipova',
  },
  {
    id: 'speaker-019',
    userId: 'speaker-user-019',
    name: 'Artem Kuzin',
    email: 'artem.kuzin@example.com',
    company: 'FinTech Core',
    position: 'Backend Developer',
    bio: 'Artem Kuzin работает в FinTech Core и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/artem_kuzin',
    pastTalks:
      'Artem Kuzin: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Artem%20Kuzin',
  },
  {
    id: 'speaker-020',
    userId: 'speaker-user-020',
    name: 'Marina Gromova',
    email: 'marina.gromova@example.com',
    company: 'TeamFlow',
    position: 'Agile Coach',
    bio: 'Marina Gromova работает в TeamFlow и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/marina_gromova',
    pastTalks:
      'Marina Gromova: production case studies, internal tooling, engineering practices',
    avatarUrl:
      'https://api.dicebear.com/8.x/initials/svg?seed=Marina%20Gromova',
  },
  {
    id: 'speaker-021',
    userId: 'speaker-user-021',
    name: 'Gleb Tarasov',
    email: 'gleb.tarasov@example.com',
    company: 'InfraWorks',
    position: 'SRE',
    bio: 'Gleb Tarasov работает в InfraWorks и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/gleb_tarasov',
    pastTalks:
      'Gleb Tarasov: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Gleb%20Tarasov',
  },
  {
    id: 'speaker-022',
    userId: 'speaker-user-022',
    name: 'Lena Vinogradova',
    email: 'lena.vinogradova@example.com',
    company: 'LearnTech',
    position: 'Mentor',
    bio: 'Lena Vinogradova работает в LearnTech и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/lena_vinogradova',
    pastTalks:
      'Lena Vinogradova: production case studies, internal tooling, engineering practices',
    avatarUrl:
      'https://api.dicebear.com/8.x/initials/svg?seed=Lena%20Vinogradova',
  },
  {
    id: 'speaker-023',
    userId: 'speaker-user-023',
    name: 'Stepan Nikitin',
    email: 'stepan.nikitin@example.com',
    company: 'GraphWorks',
    position: 'API Engineer',
    bio: 'Stepan Nikitin работает в GraphWorks и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/stepan_nikitin',
    pastTalks:
      'Stepan Nikitin: production case studies, internal tooling, engineering practices',
    avatarUrl:
      'https://api.dicebear.com/8.x/initials/svg?seed=Stepan%20Nikitin',
  },
  {
    id: 'speaker-024',
    userId: 'speaker-user-024',
    name: 'Vera Lobanova',
    email: 'vera.lobanova@example.com',
    company: 'Visual Data',
    position: 'Data Visualization Engineer',
    bio: 'Vera Lobanova работает в Visual Data и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/vera_lobanova',
    pastTalks:
      'Vera Lobanova: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Vera%20Lobanova',
  },
  {
    id: 'speaker-025',
    userId: 'speaker-user-025',
    name: 'Ilya Medvedev',
    email: 'ilya.medvedev@example.com',
    company: 'Enterprise UI',
    position: 'Senior React Developer',
    bio: 'Ilya Medvedev работает в Enterprise UI и регулярно выступает о практической разработке, архитектурных решениях и командных процессах. В докладах делает упор на реальные кейсы, ограничения бизнеса и решения, которые можно применить в продуктовой команде.',
    contacts: 'https://t.me/ilya_medvedev',
    pastTalks:
      'Ilya Medvedev: production case studies, internal tooling, engineering practices',
    avatarUrl: 'https://api.dicebear.com/8.x/initials/svg?seed=Ilya%20Medvedev',
  },
] satisfies Speaker[];

export const speakers: Speaker[] = [...initialSpeakers];

export const createSpeaker = (input: SpeakerInput): Speaker => {
  const randomId = crypto.randomUUID();

  const speaker: Speaker = {
    id: randomId,
    userId: randomId,
    name: input.name,
    email: input.email,
    company: input.company,
    position: input.position,
    bio: input.bio,
    contacts: input.contacts,
    pastTalks: `${randomId} speaker past talks`,
    avatarUrl: `${randomId} speaker avatarUrl`,
  };

  speakers.push(speaker);

  return speaker;
};
